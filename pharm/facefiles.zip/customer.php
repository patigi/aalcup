<?php require_once('Connections/pharmConn.php'); ?>
<?php 
$fname = $_POST['cusFname'];
$lname = $_POST['cusLname'];
$cusPid = $_POST['cusPid'];
$cusId = $_POST['cusId'];
$rand = rand(1, 1000000);
$rand2 = 'p'.rand(1, 1000000);
if(isset($_GET['status']) && $_GET['status']='dispense'){
$cusPid = $_GET['cusPid'];
$cusId = $_GET['cusId'];
$fname = $_GET['fname'];
$lname = $_GET['lname'];

}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

//=====insert cutomer detail into sale==============================================

//=====insert new  customer==============================================
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "cusrecord")) {
  $insertSQL = sprintf("INSERT INTO customer (cusId, cusPid, cusFname, cusLname) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['cusId'], "text"),
                       GetSQLValueString($_POST['cusPid'], "text"),
                       GetSQLValueString($_POST['cusFname'], "text"),
                       GetSQLValueString($_POST['cusLname'], "text"));

  mysql_select_db($database_pharmConn, $pharmConn);
  $Result1 = mysql_query($insertSQL, $pharmConn) or die(mysql_error());

}
//----- Recordset of drugs from the stock------------------------------------
mysql_select_db($database_pharmConn, $pharmConn);
$query_stockSet = "SELECT stock.stockcost, stock.stockprice, stock.availableqty, registerdrug.drugid, registerdrug.drugname, (@rownum:=@rownum + 1) AS sn FROM stock LEFT JOIN registerdrug ON stock.stockdid=registerdrug.drugid, (SELECT @rownum := 0)t";
$stockSet = mysql_query($query_stockSet, $pharmConn) or die(mysql_error());
$row_stockSet = mysql_fetch_assoc($stockSet);
$totalRows_stockSet = mysql_num_rows($stockSet);

mysql_select_db($database_pharmConn, $pharmConn);
$query_customerOrder = "SELECT sale.scusDid, sale.scusQty, sale.scusCost, registerdrug.drugname, (@rownum:=@rownum + 1) AS sn FROM sale LEFT JOIN registerdrug ON  sale.scusDid= registerdrug.drugid, (SELECT @rownum:=0)t WHERE sale.salecusId = '$cusId' AND sale.scusPid = '$cusPid'";
$customerOrder = mysql_query($query_customerOrder, $pharmConn) or die(mysql_error());
$row_customerOrder = mysql_fetch_assoc($customerOrder);
$totalRows_customerOrder = mysql_num_rows($customerOrder);
?>

<div id="page-wrapper">

<div class="container-fluid">

               

                <div class="row">
                    <div class="col-lg-8">
                        <h2>New Stock</h2>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Drug Name</th>
                                        <th>Price</th>
                                        <th>Cost</th>
                                        <th>Available Qty</th>
                                        <th>Dispense</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php do { ?>
                                    <tr>
                                        <td><?php echo $row_stockSet['sn']; ?></td>
                                        <td><?php echo $row_stockSet['drugname']; ?></td>
                                        <td><?php echo $row_stockSet['stockprice']; ?></td>
                                        <td><?php echo $row_stockSet['stockcost']; ?></td>
                                        <td><?php echo $row_stockSet['availableqty']; ?></td>
                                        <td><a href="dispense.php?did=<?php echo $row_stockSet['drugid']; ?>&cusPid=<?php echo $cusPid; ?>&cusId=<?php echo $cusId; ?>&fname=<?php echo $fname; ?>&lname=<?php echo $lname; ?>" rel="facebox" class="btn btn-default">Dispense</a></td>
                                      </tr>
                                      <?php } while ($row_stockSet = mysql_fetch_assoc($stockSet)); ?>
                                </tbody>
                            </table>
                        </div>
                        </div>
                        <div class="col-lg-3">
                        <table class="table table-bordered table-hover table-striped">
                               <h3>Customer Orders</h3>
                               <h4><?php echo $fname; ?>&nbsp;<?php echo $lname; ?></h4>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Drug</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php do { ?>
  <tr>
    <td><?php echo $row_customerOrder['sn']; ?></td>
    <td><?php echo $row_customerOrder['drugname']; ?></td>
    <td><?php echo $row_customerOrder['scusCost']; ?></td>
    <td><?php echo $row_customerOrder['scusQty']; ?></td>
    <td><a href="">Delete</a></td>
  </tr>
  <?php } while ($row_customerOrder = mysql_fetch_assoc($customerOrder)); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div>
                    
                  <div class="row row-lg">
            <div class="col-lg-4 col-md-6">
              <!-- Example Form Modal -->
              <div class="example-wrap">
                <div class="example">
                  <div class="example-well height-350">
                  </div>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleFormModal" aria-hidden="false" aria-labelledby="exampleFormModalLabel"
                  role="dialog" tabindex="-1">
                    <div class="modal-dialog">
                      <form class="modal-content" method="POST" name="cusrecord" action="index2.php?x4">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="exampleFormModalLabel">Stock Schedule</h4>
                        </div>
                        <div class="modal-body">
                          <div class="row">
                            <div class="col-lg-4 form-group">
                              <input type="text" class="form-control" name="cusFname" placeholder="Firs Name" required="required">
                            </div>
                            <div class="col-lg-4 form-group">
                              <input type="text" class="form-control" name="cusLname" placeholder="Last Name" required="required">
                              <input type="hidden" value="<?php echo $rand; ?>" name="cusPid" />
                              <input type="hidden" value="<?php echo $rand2; ?>" name="cusId"/>
                            </div>
                            <div class="col-sm-12 pull-right">
                              <button class="btn btn-primary btn-outline" type="submit">Proceed</button>
                              <input type="hidden" name="MM_insert" value="cusrecord"/>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <!-- End Modal -->
                </div>
              </div>
              <!-- End Example Form Modal -->
            </div>

                </div>
                <!-- /.row -->

               

            </div>
            <!-- /.container-fluid -->
<?php 
$set = $_GET['set'];
if(isset($set)){ ?>
<script>
$(document).ready(function(){

$("#exampleFormModal").modal('show');
	
});
</script>
<?php 
}
?>

        
        <?php
mysql_free_result($stockSet);

mysql_free_result($customerOrder);
?>
