<?php require_once('Connections/pharmConn.php'); ?>
<?php
$did = $_GET['did'];
$cusid = $_GET['cusId'];
$cuspid = $_GET['cusPid'];
$fname = $_GET['$fname'];
$lname = $_GET['$lname'];

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
	echo $date = date('Y-d-m');
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "sales")) {
	$date = date('Y-m-d');
  $insertSQL = sprintf("INSERT INTO sale (salecusId, scusPid, scusDid, scusQty, scusCost, scusDate) VALUES (%s, %s, %s, %s, %s, '$date')",
                       GetSQLValueString($_POST['salecusId'], "text"),
                       GetSQLValueString($_POST['scusPid'], "int"),
                       GetSQLValueString($_POST['scusDid'], "int"),
                       GetSQLValueString($_POST['scusQty'], "int"),
                       GetSQLValueString($_POST['scusCost'], "int"));

  mysql_select_db($database_pharmConn, $pharmConn);
  $Result1 = mysql_query($insertSQL, $pharmConn) or die(mysql_error());
$query_availableQty = "SELECT stock.availableqty FROM stock WHERE stock.stockdid = '$did'";
$availableQty = mysql_query($query_availableQty, $pharmConn) or die(mysql_error());
$row_availableQty = mysql_fetch_assoc($availableQty);
$totalRows_availableQty = mysql_num_rows($availableQty);

$availableStock = $row_availableQty['availableqty'];
$qtyOrdered = $_POST['scusQty'];
$newqty = $availableStock-$qtyOrdered;

$update_query = mysql_query("UPDATE stock SET availableqty = '$newqty' WHERE stockdid = '$did'");

  $insertSQL3 = sprintf("INSERT INTO bincard (bindid, qtyout, qtybal) VALUES ('$did', '{$_POST['scusQty']}', '$newqty')");
    mysql_select_db($database_pharmConn, $pharmConn);
  $Result3 = mysql_query($insertSQL3, $pharmConn) or die(mysql_error());

  $insertGoTo = "index2.php?x4&$cusid&$cusPid&status=dispense&cusFname=$fname&cusLname=$lname&nwqty=$newqty";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_pharmConn, $pharmConn);
$query_drugdetailSet = "SELECT stock.stockdid, stock.stockcost, stock.stockprice, stock.availableqty, registerdrug.drugname FROM stock LEFT JOIN registerdrug ON  stock.stockdid= registerdrug.drugid WHERE stock.stockdid = '$did'";
$drugdetailSet = mysql_query($query_drugdetailSet, $pharmConn) or die(mysql_error());
$row_drugdetailSet = mysql_fetch_assoc($drugdetailSet);
$totalRows_drugdetailSet = mysql_num_rows($drugdetailSet);



 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<script>
function chang(){
	var qty = document.getElementById('orqty').value;
	var cost = document.getElementById('stockcost').value;
	var tcost = qty * cost;
	
	document.getElementById('drugcost').value = tcost;
}
</script>
<form action="<?php echo $editFormAction; ?>" method="POST" name="sales">
                        <div  style="width: 600px;">
                          <h4 class="modal-title">Add to Stock</h4>
                        </div>
                          <div class="row">
                            <div class="col-lg-4 form-group">
                            <label>Drug Name</label>
                            <input type="hidden" value="<?php echo $cusid; ?>" name="salecusId" />
                            <input type="hidden" value="<?php echo $cuspid; ?>" name="scusPid" />
                              <input class="form-control" type="text" value="<?php echo $row_drugdetailSet['drugname']; ?>" name="Schdrugid" readonly="readonly"/>
                              <input type="hidden" value="<?php echo $did; ?>" name="scusDid" />
                            </div>
                            <div class="col-lg-4 form-group">
                            <label>Avilable Drug Qty</label>
                              <input type="text" class="form-control" value="<?php echo $row_drugdetailSet['availableqty']; ?>" name="availableqty" placeholder="Quantity">
                            </div>
                            <div class="col-lg-4 form-group">
                            <label>Drug Price</label>
                              <input type="text" class="form-control" value="<?php echo $row_drugdetailSet['stockprice']; ?>" name="stockcost" id="stockcost" />
                            </div>
                            <div class="col-lg-12"><hr /></div>
                            <div class="col-lg-6 form-group">
                            
					        <label>Ordered Qty</label>
                              <input class="form-control" type="text" value=""  name="scusQty" id="orqty" onkeyup="chang()" />
                            </div>
                            <div class="col-lg-6 form-group">
                            <label>Ordered Cost</label>
                              <input class="form-control" type="text" value="" placeholder="Set Price" name="scusCost" id="drugcost" />
                            </div>
                            <div class="col-sm-12 pull-right">
                              <button class="btn btn-primary btn-outline" type="submit">ORDER</button>
                            </div>
                            
                          </div>
                          <input type="hidden" name="MM_insert" value="sales" />
                        </div>
  </form>

</body>
</html>
<?php
mysql_free_result($drugdetailSet);

?>
