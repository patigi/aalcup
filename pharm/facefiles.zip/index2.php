
<?php 
$x1= $_GET['x1'];
$x2= $_GET['x2'];
$x3= $_GET['x3'];
$x4= $_GET['x4'];
$x5= $_GET['x5'];
$x6= $_GET['x6'];
$x7= $_GET['x7'];
$x8= $_GET['x8'];
$x9= $_GET['x9'];
 ?>
<?php include_once("head.php");?>
<?php
if(isset ($x1)){
 include_once("dashboard.php");
}
 ?>
 
<?php 
if(isset ($x2)){
	include("schedule.php");	
}
?>
<?php 
if(isset ($x3)){
	include("supplier.php");	
}
?>
<?php 
if(isset ($x4)){
	include("customer.php");	
}
?>
<?php 
if(isset ($x5)){
	include("stock.php");	
}
?>
<?php 
if(isset ($x6)){
	include("newproduct.php");	
}
?>
<?php 
if(isset ($x7)){
	include("sales.php");	
}
?>
<?php 
if(isset ($x8)){
	include("generatereport.php");	
}
?>
<?php 
if(isset ($x9)){
	include("bincard.php");	
}
?>
<?php include_once("foot.php");?>

